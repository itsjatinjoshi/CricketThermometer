package com.example.cricketthermometer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    EditText eText;
    Button btn;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eText =findViewById(R.id.eText);
        btn = findViewById(R.id.btn);
        tvResult= findViewById(R.id.tvResult);

        tvResult.setVisibility(View.GONE);

      btn.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              if(eText.getText().toString().isEmpty())
              {
                  Toast.makeText(MainActivity.this, "Please enter all field", Toast.LENGTH_SHORT).show();
              }
              else
              {
                  int chirps = Integer.parseInt(eText.getText().toString().trim());
                  double temp = (chirps/3.0) + 4;
                  String result = "The approximate outside temprature is " + temp + " degree celcius";
                  tvResult.setText(result);
                  tvResult.setVisibility(View.VISIBLE);
              }
          }
      });
    }
}
